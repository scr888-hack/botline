# -*- coding: utf-8 -*-

from LineAPI.linepy import *
from liff.ttypes import LiffChatContext, LiffContext, LiffSquareChatContext, LiffNoneContext, LiffViewRequest
from LineAPI.akad.ttypes import Message
from LineAPI.akad.ttypes import ContentType as Type
from LineAPI.akad.ttypes import TalkException
from datetime import datetime, timedelta
from time import sleep
from bs4 import BeautifulSoup as bSoup
from bs4 import BeautifulSoup
from humanfriendly import format_timespan, format_size, format_number, format_length
#from gtts import gTTS
from threading import Thread
from io import StringIO
from multiprocessing import Pool
from googletrans import Translator
from urllib.parse import urlencode
from tmp.MySplit import *
from random import randint
from shutil import copyfile
from youtube_dl import YoutubeDL
import subprocess, youtube_dl, humanize, traceback
import subprocess as cmd
import platform
import requests, json
import time, random, sys, json, null, pafy, codecs, html5lib ,shutil ,threading, glob, re, base64, string, os, requests, six, ast, pytz, wikipedia, urllib, urllib.parse, atexit, asyncio, traceback, livejson
_session = requests.session()
#==============================================================================

# cl = LINE('')
cl = LINE('admin','1478aaaa')
cl.log("Auth Token : " + str(cl.authToken))
cl.log("Timeline Token : " + str(cl.tl.channelAccessToken))


lineProfile = cl.getProfile()
mid = cl.getProfile().mid

oepoll = OEPoll(cl)
call = cl
creator = ["ue4f352830e5d53cd4f784267e8eb0c48","ใส่MIDคนคุม",mid]
owner = ["ue4f352830e5d53cd4f784267e8eb0c48","ใส่MIDคนคุม",mid]
admin = ["ue4f352830e5d53cd4f784267e8eb0c48","ใส่MIDคนคุม",mid]
staff = ["ue4f352830e5d53cd4f784267e8eb0c48","ใส่MIDคนคุม",mid]
#==============================================================================
lineProfile = cl.getProfile()
mid = cl.getProfile().mid

KAC = [cl]
Bots = [mid]
Saints = admin + owner + staff
Team = creator + owner + admin + staff + Bots
Setbot = codecs.open("setting.json","r","utf-8")
Setmain = json.load(Setbot)
#===============================================================================
userTemp = {}
dict = {}
msg_dict = {}
msg_dict1 = {}
temp_flood = {}
dt_to_str = {}
message = []
#===============================================================================
settings = {
    "autoBlock": False,
    "autoRead": True,
    "autolike": True,
    "com": True,
    "postId": [],
    "commet": """👉 ใส่คอมเม้นออโต้ไลค์ By.AgentONE 👈""",
    "postEndUrl": False,
    "checkPost": False,
    "welcome": False,
    "leave": False,
    "mid": False,
    "replySticker": False,
    "stickerOn": False,
    "checkContact": False,
    "postEndUrl": False,
    "checkPost": False,
    "setKey": "",
    "restartPoint": False,
    "checkSticker": False,
    "userMentioned": False,
    "listSticker": False,
    "messageSticker": False,
    "changeGroupPicture": [],
    "keyCommand": "",
    "AddstickerTag": {
        "sid": "",
        "spkg": "",
        "status": False
            },
    "Addsticker":{
            "name": "",
            "status":False
            },
    "stk":{},
    "selfbot":True,
    "Images":{},
    "Img":{},
    "Addimage":{
            "name": "",
            "status":False
            },
    "Videos":{},
    "Addaudio":{
            "name": "",
            "status":False
            },
    "Addvideo":{
            "name": "",
            "status":False
            },
    "myProfile": {
        "displayName": "",
        "coverId": "",
        "pictureStatus": "",
        "statusMessage": ""
    },
    "mimic": {
        "copy": False,
        "status": False,
        "target": {}
    }, 
    "unsendMessage": False,
    "Picture":False,
    "group":{},
    "groupPicture":False,
    "changePicture":False,
    "changeProfileVideo": False,
    "ChangeVideoProfilevid":{},
    "ChangeVideoProfilePicture":{},
    "autoJoinTicket":False,
    "SpamInvite":False,
    "displayName": "",
    "userAgent": [
        "Mozilla/5.0 (X11; U; Linux i586; de; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (X11; U; Linux amd64; rv:5.0) Gecko/20100101 Firefox/5.0 (Debian)",
        "Mozilla/5.0 (X11; U; Linux amd64; en-US; rv:5.0) Gecko/20110619 Firefox/5.0",
        "Mozilla/5.0 (X11; Linux) Gecko Firefox/5.0",
        "Mozilla/5.0 (X11; Linux x86_64; rv:5.0) Gecko/20100101 Firefox/5.0 FirePHP/0.5",
        "Mozilla/5.0 (X11; Linux x86_64; rv:5.0) Gecko/20100101 Firefox/5.0 Firefox/5.0",
        "Mozilla/5.0 (X11; Linux x86_64) Gecko Firefox/5.0",
        "Mozilla/5.0 (X11; Linux ppc; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (X11; Linux AMD64) Gecko Firefox/5.0",
        "Mozilla/5.0 (X11; FreeBSD amd64; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 6.2; WOW64; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:5.0) Gecko/20110619 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 6.1; rv:6.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 6.1.1; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 5.2; WOW64; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 5.1; U; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 5.1; rv:2.0.1) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 5.0; WOW64; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 5.0; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/35.200.32.99 Safari/537.36"
    ]
}

wait = {
    "limit": 2,
    "owner":{},
    "admin":{},
    "addadmin":False,
    "delladmin":False,
    "postId": [],
    "staff":{},
    "dhenza":{},
    "Timeline": False,
    "invite":False,
    "addstaff":False,
    "dellstaff":False,
    "bots":{},
    "addbots":False,
    "dellbots":False,
    "blacklist":{},
    "wblacklist":False,
    "dblacklist":False,
    "Talkblacklist":{},
    "Talkwblacklist":False,
    "Talkdblacklist":False,
    "talkban":False,
    "contact":False,
    "downos":False,
    'autoJoin':True,
    'autoAdd':False,
    'autoCancel':{"on":True, "members":3},
    'autoLeave':False, 
    'autoLeave1':False,
    "detectMention":False,
    "MentionKick":False,
    "welcomeOn":False,
    "sticker":False,  
    "selfbot":True,
    "mention":"",
    "Respontag":"",
    "welcome":"",
    "comment1":"",
    "message":""
}
mulai = time.time()

tz = pytz.timezone("Asia/Jakarta")
timeNow = datetime.now(tz=tz)


#=====================================================================#
def bcTemplate(gr, data):
    xyz = LiffChatContext(gr)
    xyzz = LiffContext(chat=xyz)
    view = LiffViewRequest('1561513258-Do0kgM9x', xyzz)
    token = cl.liff.issueLiffView(view)
    url = 'https://api.line.me/message/v3/share'
    headers = {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer %s' % token.accessToken
    }
    data = {"messages":[data]}
    requests.post(url, headers=headers, data=json.dumps(data))
def sendTemplate(group, data):
    xyz = LiffChatContext(group)
    xyzz = LiffContext(chat=xyz)
    view = LiffViewRequest('1561513258-Do0kgM9x', xyzz)
    token = cl.liff.issueLiffView(view)
    url = 'https://api.line.me/message/v3/share'
    headers = {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer %s' % token.accessToken
    }
    data = {"messages":[data]}
    requests.post(url, headers=headers, data=json.dumps(data))

def sendTemplate(to, data):
    xyz = LiffChatContext(to)
    xyzz = LiffContext(chat=xyz)
    view = LiffViewRequest('1561513258-Do0kgM9x', xyzz)
    token = cl.liff.issueLiffView(view)
    url = 'https://api.line.me/message/v3/share'
    headers = {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer %s' % token.accessToken
    }
    data = {"messages":[data]}
    requests.post(url, headers=headers, data=json.dumps(data))
def restart_program():
    python = sys.executable
    os.execl(python, python, * sys.argv)
    
def restartBot():
    python = sys.executable
    os.execl(python, python, *sys.argv)


def waktu(secs):
    mins, secs = divmod(secs,60)
    hours, mins = divmod(mins,60)
    days, hours = divmod(hours, 24)
    return '%02d ว̶ั̶น̶ %02d ช̶ม̶.̶ %02d น̶า̶ท̶ี̶ %02d ว̶ิ̶น̶า̶ท̶ี̶' % (days, hours, mins, secs)

def command(text):
    pesan = text.lower()
    if pesan.startswith(Setmain['keyCommand']):
        cmd = pesan.replace(Setmain['keyCommand'],"")
    else:
        cmd = "command"
    return cmd

def help():
    num = 1
    key = Setmain["keyCommand"]
    key = key.title()
    helpMessage = """•B̶o̶t̶ ̶N̶o̶N̶a̶m̶e̶ ̶O̶S̶M̶ ̶1̶.̶1̶.̶2̶ •
คำสั่ง
on
off
เชคค่า
ลบแชท
รีบูท
ออน
กลุ่ม
ออกละ
ออก (ใส่ชื่อห้อง)
sp
speed
เข้าเปิด
เข้าปิด
บล็อคเปิด
บล็อคปิด
มุดลิ้งเปิด
มุดลิ้งปิด
ประกาศ (ตามโดยข้อความและ/IDLINE)
นอต1
นอต2
นอต3
นอต4
นอต5
นอต6
นอต7
นอต8
นอต9"""
    return helpMessage


def bot(op):
    global time
    global ast
    global groupParam
    try:
        if op.type == 0:
            return
        if op.type == 5:
            if settings["autoBlock"] == True:
                cl.blockContact(op.param1)
        if op.type == 5:
            print ("[ 5 ] Add Contact")
            if wait["autoAdd"] == True:
                cl.findAndAddContactsByMid(op.param1)                           

        if op.type == 13:
            if mid in op.param3:
                if wait["autoJoin"] == True:
                    if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                        cl.acceptGroupInvitation(op.param1)
                        ginfo = cl.getGroup(op.param1)
                    else:
                        cl.acceptGroupInvitation(op.param1)
                        ginfo = cl.getGroup(op.param1)
        if op.type == 13:
            if mid in op.param3:
                G = cl.getGroup(op.param1)
                if settings["autoJoin"] == True:
                    if settings["autoCancel"]["on"] == True:
                        if len(G.members) <= settings["autoCancel"]["members"]:
                            cl.rejectGroupInvitation(op.param1)
                        else:
                            cl.acceptGroupInvitation(op.param1)
                    else:
                        cl.acceptGroupInvitation(op.param1)
                elif settings["autoCancel"]["on"] == True:
                    if len(G.members) <= settings["autoCancel"]["members"]:
                        cl.rejectGroupInvitation(op.param1)
            else:
                Inviter = op.param3.replace("",',')
                InviterX = Inviter.split(",")
                matched_list = []
                for tag in settings["blacklist"]:
                    matched_list+=[str for str in InviterX if str == tag]
                if matched_list == []:
                    pass
                else:
                    cl.cancelGroupInvitation(op.param1, matched_list)   
#====================================================================                           
                              
#====================================================================                            

             
        if op.type == 0:
            return
        if op.type == 5:
            if wait["autoBlock"] == True:
                if op.param2 not in Bots and op.param2 not in admin:
                    if (wait["message"] in [" "," ","\n",None]):
                        pass
                    else:
                        cl.sendMessage(op.param1, wait["message"])
                        

#====================================================================                            
 
#===================================================================================================   
  
        if op.type in [25, 26]:           
            msg = op.message
            text = str(msg.text)
            msg_id = msg.id
            receiver = msg.to
            sender = msg._from
            cmd = command(text)
            isValid = True
            setKey = settings["keyCommand"].title()
            if settings["setKey"] == False: setKey = ''
            if isValid != False:
                if msg.toType == 0 and sender != mid: to = sender
                else: to = receiver
                if receiver in temp_flood:
                    if temp_flood[receiver]["expire"] == True:
                        if cmd == "open" and sender == mid:
                            temp_flood[receiver]["expire"] = False
                            temp_flood[receiver]["time"] = time.time()
                            cl.sendMessage(to, "Bot kembali aktif")
                        return
                    elif time.time() - temp_flood[receiver]["time"] <= 1:
                        temp_flood[receiver]["flood"] += 1
                        if temp_flood[receiver]["flood"] >= 20:
                            temp_flood[receiver]["flood"] = 0
                            temp_flood[receiver]["expire"] = True
                            ret_ = " {}".format(setKey)
                            cl.sendMessage(to, str(ret_))
                    else:
                         temp_flood[receiver]["flood"] = 0
                         temp_flood[receiver]["time"] = time.time()
                else:
                    temp_flood[receiver] = {
                        "time": time.time(),
                        "flood": 0,
                        "expire": False
                    }             
#===================================================================================================        
        if op.type == 55:
            if op.param2 in wait["blacklist"]:
                random.choice(ABC).kickoutFromGroup(op.param1,[op.param2])
            else:
                pass


                                                                     
        if op.type == 25 or op.type == 26:
            msg = op.message
            text = msg.text
            msg_id = msg.id
            receiver = msg.to
            sender = msg._from
            if msg.contentType == 0:
                msg_dict[msg.id] = {"text":msg.text,"from":msg._from,"createdTime":msg.createdTime}
        if op.type == 26:
           if wait["selfbot"] == True:
               msg = op.message
               if msg._from not in Bots:
                   if msg._from in wait["blacklist"]:
                      try:
                          random.choice(ABC).kickoutFromGroup(msg.to, [msg._from])
                      except:
                          try:
                              random.choice(ABC).kickoutFromGroup(msg.to, [msg._from])
                          except:
                              random.choice(ABC).kickoutFromGroup(msg.to, [msg._from])
               if msg.contentType == 16:
                   if msg.toType in [2,1,0]:
                       print ("AutoLikeCommat")
                       try:
                           if settings["autolike"] == True:
                               purl = msg.contentMetadata["postEndUrl"].split('userMid=')[1].split('&postId=')
                               if purl[1] not in wait['postId']:
                                   cl.likePost(purl[0], purl[1], random.choice([1001]))
                               if settings["com"] == True:
                                   cl.createComment(purl[0], purl[1], settings["commet"])
                                   wait['postId'].append(purl[1])
                               else:
                                   pass
                       except Exception as e:
                               if settings["autolike"] == True:
                                   purl = msg.contentMetadata['postEndUrl'].split('homeId=')[1].split('&postId=')
                                   if purl[1] not in wait['postId']:
                                       cl.likePost(msg._from, purl[1], random.choice([1001]))
                                   if settings["com"] == True:
                                       cl.createComment(msg._from, purl[1], settings["commet"])
                                       wait['postId'].append(purl[1])
                                   else:pass
        if op.type == 25 or op.type == 26:
            msg = op.message
            text = msg.text
            msg_id = msg.id
            receiver = msg.to
            sender = msg._from
            if msg.toType == 2:
               if msg.toType == 0:
                    to = msg._from
               elif msg.toType == 2:
                    to = msg.to
               if msg.contentType == 0:
                    msg_dict[msg.id] = {"text":msg.text,"from":msg._from,"createdTime":msg.createdTime}
                    if text is None:
                        return
                    else:
                        cmd = command(text)
                        if cmd == "คำสั่ง":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               helpMessage = help()
                               cl.sendMessage(msg.to, str(helpMessage))
                                       
                        if cmd == "on":
                            if msg._from in admin:
                                wait["selfbot"] = True
                                cl.sendMessage(msg.to, "ร̶ะ̶บ̶บ̶เ̶ซ̶ล̶บ̶อ̶ท̶เ̶ร̶ิ̶̶่ม̶ท̶ำ̶ง̶า̶น̶")
                                
                        elif cmd == "off":
                            if msg._from in admin:
                                wait["selfbot"] = False
                                cl.sendMessage(msg.to, "ร̶ะ̶บ̶บ̶เ̶ซ̶ล̶บ̶อ̶ท̶ถ̶̶ูก̶ป̶ิ̶ด̶ก̶า̶ร̶ต̶อ̶บ̶ส̶น̶อ̶ง̶")
        
                        elif cmd == "เชคค่า":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                tz = pytz.timezone("Asia/Jakarta")
                                timeNow = datetime.now(tz=tz)
                                md = "   •B̶o̶t̶ ̶N̶o̶N̶a̶m̶e̶ ̶O̶S̶M̶ ̶1̶.̶1̶.̶2̶ •\n"
                                if wait["sticker"] == True: md+="【✔】เ̶ช̶็̶ค̶ส̶ต̶ิ̶̶๊ก̶เ̶ก̶อ̶ร̶์̶\n"
                                else: md+="【✘】เ̶ช̶็̶ค̶ส̶ต̶ิ̶̶๊ก̶เ̶ก̶อ̶ร̶์̶r\n"
                                if wait["contact"] == True: md+="【✔】เ̶ช̶็̶ค̶ค̶ท̶\n"
                                else: md+="【✘】เ̶ช̶็̶ค̶ค̶ท̶\n"
                                if wait["autoJoin"] == True: md+="【✔】เ̶ข̶̶้า̶อ̶อ̶โ̶ต̶̶้\n"
                                else: md+="【✘】เ̶ข̶̶้า̶อ̶อ̶โ̶ต̶̶้\n"
                                if settings["autoJoinTicket"] == True: md+="【✔】ม̶̶ุด̶ล̶ิ̶̶้ง̶ค̶์̶อ̶อ̶โ̶ต̶̶้\n"
                                else: md+="【✘】ม̶̶ุด̶ล̶ิ̶̶้ง̶ค̶์̶อ̶อ̶โ̶ต̶̶้\n"
                                if wait["autoAdd"] == True: md+="【✔】แ̶อ̶ด̶อ̶ั̶ต̶โ̶น̶ม̶ั̶ต̶ิ̶\n"
                                else: md+="【✘】แ̶อ̶ด̶อ̶ั̶ต̶โ̶น̶ม̶ั̶ต̶ิ̶\n"
                                cl.sendMessage(msg.to, md+"\nว̶ั̶น̶ท̶ี̶̶่ "+ datetime.strftime(timeNow,'%Y-%m-%d')+"\nเ̶ว̶ล̶า̶ "+ datetime.strftime(timeNow,'%H:%M:%S')+" ")
                        elif text.lower() == "ลบแชท":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               try:
                                   cl.removeAllMessages(op.param2)
                                   cl.sendMessage(msg.to,"ล̶บ̶แ̶ช̶ท̶เ̶ร̶ี̶ย̶บ̶ร̶̶้อ̶ย̶")

                               except:
                                   pass

                        elif cmd == "รีบูท":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               cl.sendMessage(msg.to, "ก̶ำ̶ล̶ั̶ง̶เ̶ร̶ิ̶̶่ม̶ก̶า̶ร̶ร̶ี̶บ̶̶ูท̶โ̶ป̶ร̶ร̶อ̶")
                               Setmain["restartPoint"] = msg.to
                               restartBot()
                               cl.sendMessage(msg.to, "Done...")
                            
                        elif cmd == "ออน":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               eltime = time.time() - mulai
                               bot = "เ̶ว̶ล̶า̶ล̶็̶อ̶ค̶อ̶ิ̶น̶ " +waktu(eltime)
                               cl.sendMessage(msg.to,bot)
                        elif cmd == "กลุ่ม":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               ma = ""
                               a = 0
                               gid = cl.getGroupIdsJoined()
                               for i in gid:
                                   G = cl.getGroup(i)
                                   a = a + 1
                                   end = "\n"
                                   ma += " " + str(a) + ". " +G.name+ "\n"
                               cl.sendMessage(msg.to,"   ร̶า̶ย̶ก̶า̶ร̶ก̶ล̶̶̶ุ่ม̶\n"+ma+" จ̶ำ̶น̶ว̶น̶"+str(len(gid))+" ก̶ล̶̶̶ุ่ม̶")
                        elif cmd == "ออกละ":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                G = cl.getGroup(msg.to)
                                cl.sendMessage(msg.to, "บ̶า̶ย̶ "+str(G.name))
                                cl.leaveGroup(msg.to)

                        elif cmd.startswith("ออก "):
                            if msg._from in admin:
                                proses = text.split(" ")
                                ng = text.replace(proses[0] + " ","")
                                gid = cl.getGroupIdsJoined()
                                for i in gid:
                                    h = cl.getGroup(i).name
                                    if h == ng:
                                        cl.sendMessage(i, "ร̶ะ̶บ̶บ̶ถ̶̶ูก̶ส̶ั̶̶่ง̶อ̶อ̶ก̶จ̶า̶ก̶แ̶อ̶ด̶ม̶ิ̶น̶")
                                        cl.leaveGroup(i)
                                        cl.sendMessage(to,"ก̶ำ̶ล̶ั̶ง̶เ̶ร̶ิ̶̶่ม̶อ̶อ̶ก̶จ̶า̶ก̶ก̶ล̶̶̶ุ่ม̶ " +h)

                        elif cmd == "speed" or cmd == "sp":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               start = time.time()                               
                               cl.sendMessage(msg.to, "•B̶o̶t̶ ̶H̶K̶A̶G̶E̶N̶T ̶O̶N̶E̶ ̶1̶.̶1̶.̶2̶ •")                               
                               elapsed_time = time.time() - start
                               cl.sendMessage(msg.to, "         ค̶ว̶า̶ม̶เ̶ร̶็̶ว̶ \n{}".format(str(elapsed_time)))

                        elif cmd == "เข้าเปิด":
                            if msg._from in admin:
                                settings["autoJoin"] = True
                                cl.sendMessage(to, "เ̶ข̶̶้า̶ก̶ล̶̶̶ุ่ม̶อ̶อ̶โ̶ต̶̶้เ̶ป̶ิ̶ด̶")
                        elif cmd == "เข้าปิด":
                            if msg._from in admin:  
                                settings["autoJoin"] = False
                                cl.sendMessage(to, "เ̶ข̶̶้า̶ก̶ล̶̶̶ุ่ม̶อ̶อ̶โ̶ต̶̶้ป̶ิ̶ด̶")
                        elif cmd == "บล็อคเปิด":
                           if msg._from in admin:
                                settings["autoBlock"] = True
                                cl.sendMessage(to, "บ̶ล̶็̶อ̶ค̶ก̶า̶ร̶แ̶อ̶ด̶เ̶ป̶ิ̶ด̶")
                        elif cmd == "บล็อคปิด":    
                            if msg._from in admin:  
                                settings["autoBlock"] = False
                                cl.sendMessage(to, "บ̶ล̶็̶อ̶ค̶ก̶า̶ร̶แ̶อ̶ด̶ป̶ิ̶ด̶")
                        elif cmd == "มุดลิ้งเปิด":
                            if msg._from in admin:
                                 settings["autoJoinTicket"] = True
                                 cl.sendMessage(to, "เ̶ป̶ิ̶ด̶ร̶ะ̶บ̶บ̶ก̶า̶ร̶เ̶ข̶̶้า̶ล̶ิ̶̶้ง̶ค̶์̶อ̶อ̶โ̶ต̶̶้")
                        elif cmd == "มุดลิ้งปิด":
                           if msg._from in admin:
                                 settings["autoJoinTicket"] = False
                                 cl.sendMessage(to, "ป̶ิ̶ด̶ร̶ะ̶บ̶บ̶ก̶า̶ร̶เ̶ข̶̶้า̶ล̶ิ̶̶้ง̶ค̶์̶อ̶อ̶โ̶ต̶̶้")  
#\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\คำสั่งประกาศรูป+ข้อความ\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\#
                        elif msg.text.lower().startswith("ประกาศ"):
                            if msg._from in admin:
                                    delcmd = msg.text.split(" ")
                                    get = msg.text.replace(delcmd[0]+" ","").split("/")
                                    kw = get[0]
                                    ans = get[1]
                                    groups = cl.getGroupIdsJoined()
                                    for group in groups:
                                        sa = "{}".format(str(kw))
                                        data = {
                                            "type": "flex",
                                            "altText": "มีคนกล่าวถึงคุณในแชท",
                                            "contents": {
                                                "type": "bubble",
                                                "hero": {
                                                    "type": "image",
                                                    "url": "https://i.imgur.com/9EXisOi.jpg",
                                                    "size": "full",
                                                    "aspectRatio": "1:1",
                                                    "aspectMode": "cover",
                                                    "action": {
                                                        "type": "uri",
                                                        "uri": "line://ti/p/~saibot10"
                                                    }
                                                },
                                                "body": {
                                                    "type": "box",
                                                    "layout": "vertical",
                                                    "contents": [
                                                        {
                                                           "type": "text",
                                                           "text": sa,
                                                           "wrap": True,
                                                           "align": "center",
                                                           "gravity": "center",
                                                           "size": "md"
                                                       },
                                                       {  
                                                           "type":"text",
                                                           "text":" "
                                                       },
                                                       {
                                                           "type":"button",
                                                           "style":"primary",
                                                           "color":"#0000ff",
                                                           "action": {
                                                               "type": "uri",
                                                               "label": "ติดต่อเรา",
                                                               "uri": "line://ti/p/~{}".format(ans),
                                                           }
                                                       }
                                                   ]
                                                }
                                            }
                                        }
                                        sendTemplate(group, data)
                                        time.sleep(1)
                                    cl.sendMessage(to, "ฝ̶า̶ก̶แ̶ล̶̶้ว̶จ̶ำ̶น̶ว̶น̶  {} ก̶ล̶̶̶ุ่ม̶ ".format(str(len(groups))))
#\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\คำสั่งฝากรูปแบบ BOXFLEX\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\#
                        if cmd == "บอดtded":
                          if msg._from in admin:
                            rah = text.split(" ")
                            matt = text.replace(rah[0] + " ","")
                            sender_profile = cl.getContact(sender)
                            groups = cl.getGroupIdsJoined()
                            for gr in groups:
                                data =  {"type": "flex","altText": "รวมเว็บสล๊อตยักษ์ใหญ่","contents": {"type":"bubble","hero":{"type":"image","url":"https://i.imgur.com/KINEGpM.png","margin":"none","size":"full","aspectRatio":"1:1","aspectMode":"cover","backgroundColor":"#160606","action":{"type":"uri","uri":"http://nav.cx/f6ypCoz"}},"body":{"type":"box","layout":"vertical","spacing":"sm","contents":[{"type":"text","text":"รวม7APPแถวหน้าของเมืองไทย","size":"xl","weight":"bold","color":"#0C0909","wrap":True},{"type":"box","layout":"baseline","flex":1,"contents":[{"type":"text","text":"โปรสุดพิเศษสำหรับคุณ","flex":0,"size":"xl","weight":"bold","wrap":True}]}]},"footer":{"type":"box","layout":"vertical","spacing":"sm","contents":[{"type":"button","action":{"type":"uri","label":"สมัครรับโบนัส50%ทันที","uri":"http://nav.cx/f6ypCoz"},"flex":2,"color":"#161616","style":"primary"},{"type":"button","action":{"type":"uri","label":"HOTTIME 20%","uri":"http://nav.cx/f6ypCoz"},"flex":2,"color":"#208110","height":"md","style":"primary"}]}}}
                                bcTemplate(gr, data)
                                time.sleep(1)
                        if cmd == "บอดsp":
                          if msg._from in admin:
                            rah = text.split(" ")
                            matt = text.replace(rah[0] + " ","")
                            sender_profile = cl.getContact(sender)
                            groups = cl.getGroupIdsJoined()
                            for gr in groups:
                                data =  {"type": "flex","altText": "918KISSฝากถอนโอนไว","contents": {"type":"bubble","hero":{"type":"image","url":"https://ahengki.com/img/sp-newuser1040.png","margin":"none","size":"full","aspectRatio":"1:1","aspectMode":"cover","backgroundColor":"#160606","action":{"type":"uri","uri":"https://bit.ly/spbl999"}},"body":{"type":"box","layout":"vertical","spacing":"sm","contents":[{"type":"text","text":"ระบบอัตโนมัติที่เร็วที่สุด","size":"xl","weight":"bold","color":"#0C0909","wrap":True},{"type":"box","layout":"baseline","flex":1,"contents":[{"type":"text","text":"ฝากถอนโอนไว918KISSยืน1","flex":0,"size":"xl","weight":"bold","wrap":True}]}]},"footer":{"type":"box","layout":"vertical","spacing":"sm","contents":[{"type":"button","action":{"type":"uri","label":"สมัครรับโบนัส50%ทันที","uri":"https://bit.ly/spbl999"},"flex":2,"color":"#161616","style":"primary"},{"type":"button","action":{"type":"uri","label":"HOTTIME 3 เวลา","uri":"https://bit.ly/spbl999"},"flex":2,"color":"#208110","height":"md","style":"primary"}]}}}
                                bcTemplate(gr, data)
                                time.sleep(1)
                        if cmd == "บอดpm":
                          if msg._from in admin:
                            rah = text.split(" ")
                            matt = text.replace(rah[0] + " ","")
                            sender_profile = cl.getContact(sender)
                            groups = cl.getGroupIdsJoined()
                            for gr in groups:
                                data =  {"type": "flex","altText": "918KISSบริการดีดุจญาติมิตร","contents": {"type":"bubble","hero":{"type":"image","url":"https://ahengki.com/img/f.pro50.png","margin":"none","size":"full","aspectRatio":"1:1","aspectMode":"cover","backgroundColor":"#160606","action":{"type":"uri","uri":"https://bit.ly/2VGex4K"}},"body":{"type":"box","layout":"vertical","spacing":"sm","contents":[{"type":"text","text":"ระบบอัตโนมัติที่เร็วที่สุด","size":"xl","weight":"bold","color":"#0C0909","wrap":True},{"type":"box","layout":"baseline","flex":1,"contents":[{"type":"text","text":"ยอดแสนก็ถอนมาแล้ว!","flex":0,"size":"xl","weight":"bold","wrap":True}]}]},"footer":{"type":"box","layout":"vertical","spacing":"sm","contents":[{"type":"button","action":{"type":"uri","label":"สมัครรับโบนัส50%ทันที","uri":"https://bit.ly/2VGex4K"},"flex":2,"color":"#161616","style":"primary"},{"type":"button","action":{"type":"uri","label":"โปรว้าวโบนัส10%ทุกยอดฝาก","uri":"https://bit.ly/2VGex4K"},"flex":2,"color":"#208110","height":"md","style":"primary"}]}}}
                                bcTemplate(gr, data)
                                time.sleep(1)
                        if cmd == "นอต2":
                          if msg._from in admin:
                            rah = text.split(" ")
                            matt = text.replace(rah[0] + " ","")
                            sender_profile = cl.getContact(sender)
                            groups = cl.getGroupIdsJoined()
                            for gr in groups:
                                data = {"type": "flex","altText": "มีคนกล่าวถึงคุณในแชท","contents": {"type":"bubble","direction":"ltr","header":{"type":"box","layout":"vertical","contents":[{"type":"text","text":"กลุ่มหางานให้น้องๆ","margin":"md","size":"xl","align":"center","weight":"bold","color":"#FFFFFF"}]},"hero":{"type":"image","url":"https://i.imgur.com/Tyak8ku.png","size":"full","aspectRatio":"1:1","aspectMode":"fit","action":{"type":"uri","uri":"https://saibotnoname.com/"}},"body":{"type":"box","layout":"vertical","contents":[{"type":"text","text":"น้องมะนาว\u200b มาใหม่ค่ะ สาวสวยหมวย X หุ่นดี อายุ23  สัดส่วน สูง 164นำ้หนัก44หน้าอก 33 ค่าขนม2500/1ชม.ครึ่ง/1นำ้ บริการดีฟิวแฟน ขี้อ้อน สดอมเสียว ขึ้นขย่มจัดให้ ไม่เร่งไม่รีบ สบายๆเต็มชั่วโมงแน่นอน พิกัด เมเจอร์รัชโยธิน,ซอย พหลโยธิน30 ไม่รับนอกสถานที่","align":"center","color":"#FFFBFB","action":{"type":"uri","uri":"https://saibotnoname.com/"},"wrap":True}]},"footer":{"type":"box","layout":"horizontal","contents":[{"type":"button","action":{"type":"uri","label":"เข้ากลุ่ม","uri":"https://saibotnoname.com/"},"color":"#0B0202","style":"primary"},{"type":"button","action":{"type":"uri","label":"กลุ่ม VIP","uri":"https://saibotnoname.com/"},"style":"primary"}]},"styles":{"header":{"backgroundColor":"#160202"},"body":{"backgroundColor":"#050505"}}}}
                                bcTemplate(gr, data)
                                time.sleep(1)
                        if cmd == "นอต3":
                          if msg._from in admin:
                            rah = text.split(" ")
                            matt = text.replace(rah[0] + " ","")
                            sender_profile = cl.getContact(sender)
                            groups = cl.getGroupIdsJoined()
                            for gr in groups:
                                data =  {"type": "flex","altText": "918KISSฝากถอนโอนไว","contents": {"type":"bubble","hero":{"type":"image","url":"https://ahengki.com/img/sp-newuser1040.png","margin":"none","size":"full","aspectRatio":"1:1","aspectMode":"cover","backgroundColor":"#160606","action":{"type":"uri","uri":"https://bit.ly/spbl999"}},"body":{"type":"box","layout":"vertical","spacing":"sm","contents":[{"type":"text","text":"ระบบอัตโนมัติที่เร็วที่สุด","size":"xl","weight":"bold","color":"#0C0909","wrap":True},{"type":"box","layout":"baseline","flex":1,"contents":[{"type":"text","text":"ฝากถอนโอนไว918KISSยืน1","flex":0,"size":"xl","weight":"bold","wrap":True}]}]},"footer":{"type":"box","layout":"vertical","spacing":"sm","contents":[{"type":"button","action":{"type":"uri","label":"สมัครรับโบนัส50%ทันที","uri":"https://bit.ly/spbl999"},"flex":2,"color":"#161616","style":"primary"},{"type":"button","action":{"type":"uri","label":"HOTTIME 3 เวลา","uri":"https://bit.ly/spbl999"},"flex":2,"color":"#208110","height":"md","style":"primary"}]}}}
                                bcTemplate(gr, data)
                                time.sleep(1)
                        if cmd == "นอต4":
                          if msg._from in admin:
                            rah = text.split(" ")
                            matt = text.replace(rah[0] + " ","")
                            sender_profile = cl.getContact(sender)
                            groups = cl.getGroupIdsJoined()
                            for gr in groups:
                                data =  {"type": "flex","altText": "มีคนกล่าวถึงคุณในแชท","contents": {"type":"bubble","header":{"type":"box","layout":"horizontal","contents":[{"type":"text","text":"คลิปเสียว.com","size":"xxl","align":"center","weight":"bold","color":"#090808","action":{"type":"uri","uri":"https://saibotnoname.com"}}]},"hero":{"type":"image","url":"https://i.imgur.com/YKeZ7CS.jpg","size":"full","aspectRatio":"1:1","aspectMode":"cover","action":{"type":"uri","label":"Action","uri":"https://saibotnoname.com"}},"body":{"type":"box","layout":"horizontal","spacing":"md","contents":[{"type":"button","action":{"type":"uri","label":"ไม่มีโฆษณา ฟรี","uri":"https://saibotnoname.com"},"style":"primary"}]},"footer":{"type":"box","layout":"horizontal","contents":[{"type":"button","action":{"type":"uri","label":"คลิกดูเลย!!!","uri":"https://saibotnoname.com"},"style":"primary"}]},"styles":{"body":{"backgroundColor":"#121010"},"footer":{"backgroundColor":"#0B0808","separatorColor":"#050202"}}}}
                                bcTemplate(gr, data)
                                time.sleep(1)
                        if cmd == "นอต5":
                          if msg._from in admin:
                            rah = text.split(" ")
                            matt = text.replace(rah[0] + " ","")
                            sender_profile = cl.getContact(sender)
                            groups = cl.getGroupIdsJoined()
                            for gr in groups:
                                data =  {"type": "flex","altText": "มีคนกล่าวถึงคุณในแชท","contents": {"type":"bubble","direction":"ltr","header":{"type":"box","layout":"horizontal","contents":[{"type":"text","text":"หอรักนักศึกษา","size":"xl","align":"center","gravity":"center","weight":"bold","color":"#000000","action":{"type":"uri","uri":"http://line.me/ti/p/~bot_botv13"}}]},"hero":{"type":"image","url":"https://i.imgur.com/k1kaXNG.png","align":"center","gravity":"center","size":"full","aspectRatio":"20:13","aspectMode":"cover","action":{"type":"uri","label":"Action","uri":"http://line.me/ti/p/~bot_botv13"}},"body":{"type":"box","layout":"horizontal","spacing":"md","contents":[{"type":"box","layout":"vertical","flex":1,"contents":[{"type":"image","url":"https://i.imgur.com/GuY6ibd.png","gravity":"bottom","size":"sm","aspectRatio":"4:3","aspectMode":"cover","action":{"type":"uri","uri":"http://line.me/ti/p/~bot_botv13"}},{"type":"image","url":"https://i.imgur.com/UMJjwTD.png","margin":"md","size":"sm","aspectRatio":"4:3","aspectMode":"cover","action":{"type":"uri","uri":"http://line.me/ti/p/~bot_botv13"}}]},{"type":"box","layout":"vertical","flex":2,"contents":[{"type":"text","text":"แอบตั้งกล้องถ่ายคลิปเย็ดกับแฟน","flex":1,"size":"xs","align":"center","gravity":"center","weight":"bold","color":"#ff0000"},{"type":"separator"},{"type":"text","text":" เย็ดกับแฟน","flex":2,"size":"xs","align":"start","gravity":"center","weight":"bold","color":"#ff0000"},{"type":"separator"},{"type":"text","text":"โดนเย็ดหลายดอกจะเพลีย ","flex":2,"size":"xs","align":"start","gravity":"center","weight":"bold","color":"#ff0000"},{"type":"separator"},{"type":"text","text":"น้องนักศึกษาปี 1 กับแฟนหนุ่ม","flex":1,"size":"xs","align":"start","gravity":"center","weight":"bold","color":"#ff0000"}]}]},"footer":{"type":"box","layout":"horizontal","contents":[{"type":"button","action":{"type":"uri","label":"สนใจระบบกด","uri":"http://line.me/ti/p/~bot_botv13"},"style":"primary"}]},"styles":{"header":{"backgroundColor":"#F7EBEB"},"body":{"backgroundColor":"#E8CDCD"}}}}
                                bcTemplate(gr, data)
                                time.sleep(1)
                        if cmd == "นอต6":
                          if msg._from in admin:
                            rah = text.split(" ")
                            matt = text.replace(rah[0] + " ","")
                            sender_profile = cl.getContact(sender)
                            groups = cl.getGroupIdsJoined()
                            for gr in groups:
                                data =  {"type": "flex","altText": "มีคนกล่าวถึงคุณในแชท","contents": {"type":"bubble","hero":{"type":"image","url":"https://media.giphy.com/media/1fhHhtoNZkJ4On3hhR/giphy.gif","size":"full","aspectRatio":"1:1","aspectMode":"cover","action":{"type":"uri","uri":"https://saibotnoname.com"}},"body":{"type":"box","layout":"vertical","spacing":"sm","contents":[{"type":"box","layout":"horizontal","contents":[{"type":"text","text":"วัยเยสสด\u200b #คลิปเพียบ","flex":0,"size":"lg","weight":"bold","action":{"type":"uri","uri":"https://saibotnoname.com"},"wrap":True}]}]},"footer":{"type":"box","layout":"vertical","spacing":"sm","contents":[{"type":"button","action":{"type":"uri","label":"กลุ่มลับ","uri":"https://saibotnoname.com"},"style":"primary"},{"type":"button","action":{"type":"uri","label":"เพิ่มเติม....","uri":"https://saibotnoname.com"},"color":"#0E0202","style":"primary"}]},"styles":{"body":{"backgroundColor":"#EEE5E5"}}}}
                                bcTemplate(gr, data)
                                time.sleep(1)
                        elif cmd == "นอต7":
                          if msg._from in admin:
                            groups = cl.getGroupIdsJoined()
                            for gr in groups:
                                data = {"type": "flex","altText": "แจกกลุ่มLIVEสดฟรี","contents": {"type":"bubble","hero":{"type":"image","url":"https://i.imgur.com/grUV5Fj.gif","size":"full","aspectRatio":"1:1","aspectMode":"cover","action":{"type":"uri","uri":"http://tiny.cc/joinGroupsex"}}}}
                                bcTemplate(gr, data)
                                time.sleep(1)
  #---------------------------------------=========แบบเลื่อน 2เลื่อน==========---------------------------------------#
                        elif msg.text.lower().startswith("นอต8"):
                          if msg._from in admin:
                                    groups = cl.getGroupIdsJoined()
                                    contact = cl.getContact(mid)
                                    cover = cl.getProfileCoverURL(mid)
                                    for group in groups:
                                        data = {"type":"flex","altText": "918KISSซองแดงถอนได้เลย","contents":{"type":"carousel","contents":[{"type":"bubble","direction":"ltr","header":{"type":"box","layout":"vertical","contents":[{"type":"text","text":"918KISSระบบอัตโนมัติ","size":"xl","align":"center","color":"#FFC100"}]},"hero":{"type":"image","url":"https://ahengki.com/img/sp-newuser1040.png","size":"full","aspectMode":"cover","action":{"type":"uri","label":"ฝาก","uri":"https://ag1.biz/spauto"}},"body":{"type":"box","layout":"vertical","contents":[{"type":"text","text":"ระบบรวดเร็วมั่นคง","size":"xxl","align":"center","weight":"bold","color":"#FF0000"},{"type":"text","text":"ทำเทิร์นแค่1เท่าถอนได้เลย","size":"xl","align":"center","weight":"bold","color":"#FFFAE3"}]},"footer":{"type":"box","layout":"vertical","contents":[{"type":"button","action":{"type":"uri","label":"สมัครสมาชิก","uri":"https://ag1.biz/spauto"},"color":"#73FF00","style":"link"},{"type":"button","action":{"type":"uri","label":"รับโบนัสทันที!!","uri":"https://ag1.biz/spauto"},"style":"primary"}]},"styles":{"header":{"backgroundColor":"#000000"},"hero":{"backgroundColor":"#000000"},"body":{"backgroundColor":"#000000"},"footer":{"backgroundColor":"#000000"}}},{"type":"bubble","direction":"ltr","header":{"type":"box","layout":"vertical","contents":[{"type":"text","text":"HOTTIME3เวลา","size":"xl","align":"center","color":"#FFC100"}]},"hero":{"type":"image","url":"https://ahengki.com/img/sp-hottime1040.png","size":"full","aspectMode":"cover"},"body":{"type":"box","layout":"horizontal","spacing":"md","contents":[{"type":"box","layout":"vertical","contents":[{"type":"image","url":"https://ahengki.com/img/bt1.jpg","size":"sm","action":{"type":"uri","label":"ฝาก","uri":"https://ag1.biz/spauto"}},{"type":"image","url":"https://ahengki.com/img/bt2.jpg","margin":"md","size":"sm","action":{"type":"uri","label":"ฝาก","uri":"https://ag1.biz/spauto"}}]},{"type":"box","layout":"vertical","flex":2,"contents":[{"type":"text","text":"สมาชิกใหม่รับโบนัส50%","flex":1,"size":"md","color":"#FFFFFF"},{"type":"separator","color":"#FFFFFF"},{"type":"text","text":"มีโปรชวนเพื่อนได้เงิน","flex":1,"size":"md","gravity":"center","color":"#FFFFFF"},{"type":"separator","color":"#FFFFFF"},{"type":"text","text":"HOTTIME3เวลา","flex":2,"size":"lg","gravity":"center","color":"#FF0000"},{"type":"separator","color":"#FFFFFF"},{"type":"text","text":"เติมกี่ครั้งก็มีโบนัส","flex":1,"size":"xs","gravity":"bottom","color":"#FFFFFF"}]}]},"footer":{"type":"box","layout":"horizontal","contents":[{"type":"button","action":{"type":"uri","label":"สมัครสมาชิก","uri":"https://ag1.biz/spauto"},"style":"primary"}]},"styles":{"header":{"backgroundColor":"#000000"},"hero":{"backgroundColor":"#000000","separatorColor":"#000000"},"body":{"backgroundColor":"#000000"},"footer":{"backgroundColor":"#000000"}}}]}} 
                                        sendTemplate(group, data)
                                        time.sleep(1)
                                    cl.sendMessage(to, "ฝ̶า̶ก̶แ̶ล̶̶้ว̶จ̶ำ̶น̶ว̶น̶{} ก̶ล̶̶̶ุ่ม̶ ".format(str(len(groups))))
#---------------------------------------=========แบบเลื่อน 3เลื่อน==========---------------------------------------#
                        elif msg.text.lower().startswith("นอต9"):
                          if msg._from in admin:
                                    groups = cl.getGroupIdsJoined()
                                    contact = cl.getContact(mid)
                                    cover = cl.getProfileCoverURL(mid)
                                    for group in groups:
                                        data = {"type":"flex","altText": "ทรายทดสอบระบบ2","contents":{"type":"carousel","contents":[{"type":"bubble","direction":"ltr","hero":{"type":"image","url":"https://i.imgur.com/Uz7W8ZU.jpg","size":"full","aspectMode":"cover"},"body":{"type":"box","layout":"vertical","contents":[{"type":"text","text":"สมัครสมาชิกรับเงินฟรี","size":"lg","align":"center","weight":"bold","color":"#DBB800"}]},"footer":{"type":"box","layout":"vertical","spacing":"md","contents":[{"type":"button","action":{"type":"uri","label":"ถอดยอด","uri":"https://saibotnoname.com"},"style":"primary"},{"type":"button","action":{"type":"uri","label":"สมัครสมาชิก","uri":"https://saibotnoname.com"},"color":"#D91C1C","style":"primary"}]},"styles":{"hero":{"backgroundColor":"#000000"},"body":{"backgroundColor":"#000000"},"footer":{"backgroundColor":"#000000"}}},{"type":"bubble","direction":"ltr","hero":{"type":"image","url":"https://i.imgur.com/Uz7W8ZU.jpg","size":"full","aspectMode":"cover"},"body":{"type":"box","layout":"vertical","contents":[{"type":"text","text":"ให้ยริการตลอด24ชม.","size":"lg","align":"center","weight":"bold","color":"#DBB800"}]},"footer":{"type":"box","layout":"vertical","spacing":"md","contents":[{"type":"button","action":{"type":"uri","label":"แทงบอลได้ตลอดเวลา","uri":"https://saibotnoname.com"},"style":"primary"},{"type":"button","action":{"type":"uri","label":"รวดเร็วตลอด 24 ชม.","uri":"https://saibotnoname.com"},"color":"#D91C1C","style":"primary"}]},"styles":{"hero":{"backgroundColor":"#000000"},"body":{"backgroundColor":"#000000"},"footer":{"backgroundColor":"#000000"}}},{"type":"bubble","direction":"ltr","hero":{"type":"image","url":"https://i.imgur.com/Uz7W8ZU.jpg","size":"full","aspectMode":"cover"},"body":{"type":"box","layout":"vertical","contents":[{"type":"text","text":"บริหารงานโดยมืออาซีพ","size":"md","align":"center","weight":"bold","color":"#DBB800"}]},"footer":{"type":"box","layout":"vertical","spacing":"md","contents":[{"type":"button","action":{"type":"uri","label":"รับแทงบอลตลอด24ชม.","uri":"https://saibotnoname.com"},"style":"primary"},{"type":"button","action":{"type":"uri","label":"เดิมพันขั้นต่ำเท่าไรก็ได้","uri":"https://saibotnoname.com"},"color":"#D91C1C","style":"primary"}]},"styles":{"hero":{"backgroundColor":"#000000"},"body":{"backgroundColor":"#000000"},"footer":{"backgroundColor":"#000000"}}}]}} 
                                        sendTemplate(group, data)
                                        time.sleep(1)
                                    cl.sendMessage(to, "ฝ̶า̶ก̶แ̶ล̶̶้ว̶จ̶ำ̶น̶ว̶น̶{} ก̶ล̶̶̶ุ่ม̶ ".format(str(len(groups))))
#*******************************************************************************************#

                        elif "/ti/g/" in msg.text.lower():
                          if wait["selfbot"] == True:
                              if settings["autoJoinTicket"] == True:
                                 link_re = re.compile('(?:line\:\/|line\.me\/R)\/ti\/g\/([a-zA-Z0-9_-]+)?')
                                 links = link_re.findall(text)
                                 n_links = []
                                 for l in links:
                                     if l not in n_links:
                                        n_links.append(l)
                                 for ticket_id in n_links:
                                     group = cl.findGroupByTicket(ticket_id)
                                     cl.acceptGroupInvitationByTicket(group.id,ticket_id)
                                     group1 = cl.findGroupByTicket(ticket_id)
                                                                        
    except Exception as error:
        print (error)
close1 = {
    "01:22:01": True,
    "01:42:01": True,
    "01:22:01": True,
    "02:12:01": True,
    "02:35:01": True,
    "02:55:01": True,
    "03:15:01": True,
    "03:35:01": True,
    "03:55:01": True,
    "04:15:01": True,
    "04:35:01": True,
    "04:55:01": True,
    "05:15:01": True,
    "05:35:01": True,
    "05:55:01": True,
    "06:15:01": True,
    "06:35:01": True,
    "06:55:01": True,
    "07:15:01": True,
    "07:35:01": True,
    "07:55:01": True,
    "08:15:01": True,
    "08:35:01": True,
    "08:55:01": True,
    "09:15:01": True,
    "09:35:01": True,
    "09:55:01": True,
    "10:15:01": True,
    "10:35:01": True,
    "10:55:01": True,
    "11:15:01": True,
    "11:35:01": True,
    "11:55:01": True,
    "12:15:01": True,
    "12:35:01": True,
    "12:55:01": True,
    "13:15:01": True,
    "13:35:01": True,
    "13:55:01": True,
    "14:15:01": True,
    "14:35:01": True,
    "14:55:01": True,
    "15:15:01": True,
    "15:35:01": True,
    "15:55:01": True,
    "16:15:01": True,
    "16:35:01": True,
    "16:55:01": True,
    "17:15:01": True,
    "17:35:01": True,
    "17:55:01": True,
    "18:15:01": True,
    "18:35:01": True, 
    "18:55:01": True,
    "19:15:01": True,
    "19:35:01": True,
    "19:55:01": True,
    "20:15:01": True,
    "20:35:01": True,
    "20:55:01": True,
    "21:15:01": True,
    "21:35:01": True,
    "21:55:01": True,
    "22:15:01": True,
    "22:35:01": True,
    "22:55:01": True,
    "23:15:01": True,
    "23:35:01": True,
    "23:55:01": True,
    "00:15:01": True,
    "00:35:01": True,
    "00:55:01": True
}
try:
    def timeclock():
        global close1
        try:
            while True:
                try:
                    time.sleep(1)
                    theTime2=time.strftime("%H:%M:%S", time.localtime())
                    print (theTime2)
                    if theTime2 in close1:
                        print ("Boardcast superrich 2textture")
                        group = cl.getGroupIdsJoined()
                        for manusia in group:
                            if manusia in group:
                                data =  {"type": "flex","altText": "รวมเว็บสล๊อตยักษ์ใหญ่","contents": {"type":"bubble","hero":{"type":"image","url":"https://i.imgur.com/KINEGpM.png","margin":"none","size":"full","aspectRatio":"1:1","aspectMode":"cover","backgroundColor":"#160606","action":{"type":"uri","uri":"http://nav.cx/f6ypCoz"}},"body":{"type":"box","layout":"vertical","spacing":"sm","contents":[{"type":"text","text":"รวม7APPแถวหน้าของเมืองไทย","size":"xl","weight":"bold","color":"#0C0909","wrap":True},{"type":"box","layout":"baseline","flex":1,"contents":[{"type":"text","text":"โปรสุดพิเศษสำหรับคุณ","flex":0,"size":"xl","weight":"bold","wrap":True}]}]},"footer":{"type":"box","layout":"vertical","spacing":"sm","contents":[{"type":"button","action":{"type":"uri","label":"สมัครรับโบนัส50%ทันที","uri":"http://nav.cx/f6ypCoz"},"flex":2,"color":"#161616","style":"primary"},{"type":"button","action":{"type":"uri","label":"HOTTIME 20%","uri":"http://nav.cx/f6ypCoz"},"flex":2,"color":"#208110","height":"md","style":"primary"}]}}}
                                sendTemplate(manusia, data)
                                time.sleep(1)
                        cl.sendMessage(Notify,"ส่งละ2")
                    else:
                        pass
                except:
                    pass
        except:
            pass
    threadTOPH3 = threading.Thread(target=timeclock)
    threadTOPH3.daemon = True
    threadTOPH3.start()
except:
    pass
    



# close3 = {
    # "06:40:01": True,
    # "07:40:01": True,
    # "08:40:01": True,
    # "09:40:01": True,
    # "10:40:01": True,
    # "11:40:01": True,
    # "12:40:01": True,
    # "13:40:01": True,
    # "14:40:01": True,
    # "15:40:01": True,
    # "16:40:01": True,
    # "17:40:01": True,
    # "18:40:01": True,
    # "19:40:01": True,
    # "20:40:01": True,
    # "21:40:01": True,
    # "22:40:01": True,
    # "23:40:01": True,
    # "00:40:01": True
# }
# try:
    # def timeclock():
        # global close3
        # try:
            # while True:
                # try:
                    # time.sleep(1)
                    # theTime2=time.strftime("%H:%M:%S", time.localtime())
                    # print (theTime2)
                    # if theTime2 in close3:
                        # print ("Notify !!")
                        # group = cl.getGroupIdsJoined()
                        # for manusia in group:
                            # if manusia in group:
                                # data = 
                                # sendTemplate(manusia, data)
                                # time.sleep(1)
                        # cl.sendMessage(Notify,"ส่งละ4")
                    # else:
                        # pass
                # except:
                    # pass
        # except:
            # pass
    # threadTOPH3 = threading.Thread(target=timeclock)
    # threadTOPH3.daemon = True
    # threadTOPH3.start()
# except:
    # pass
    

# close4 = {
    # "06:40:01": True,
    # "07:40:01": True,
    # "08:40:01": True,
    # "09:40:01": True,
    # "10:40:01": True,
    # "11:40:01": True,
    # "12:40:01": True,
    # "13:40:01": True,
    # "14:40:01": True,
    # "15:40:01": True,
    # "16:40:01": True,
    # "17:40:01": True,
    # "18:40:01": True,
    # "19:40:01": True,
    # "20:40:01": True,
    # "21:40:01": True,
    # "22:40:01": True,
    # "23:40:01": True,
    # "00:40:01": True
# }
# try:
    # def timeclock():
        # global close4
        # try:
            # while True:
                # try:
                    # time.sleep(1)
                    # theTime2=time.strftime("%H:%M:%S", time.localtime())
                    # print (theTime2)
                    # if theTime2 in close4:
                        # print ("Notify !!")
                        # group = cl.getGroupIdsJoined()
                        # for manusia in group:
                            # if manusia in group:
                                # data = 
                                # sendTemplate(manusia, data)
                                # time.sleep(1)
                        # cl.sendMessage(Notify,"ส่งละ4")
                    # else:
                        # pass
                # except:
                    # pass
        # except:
            # pass
    # threadTOPH3 = threading.Thread(target=timeclock)
    # threadTOPH3.daemon = True
    # threadTOPH3.start()
# except:
    # pass
 


while True:
    try:
        ops = oepoll.singleTrace(count=50)
        if ops is not None:
            for op in ops:
                bot(op)
                oepoll.setRevision(op.revision)
    except Exception as e:
        logError(e)

